/**
 * User Dashboard Debug Component
 * For testing user-specific API endpoints
 */

import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { userApi, UserDroplet, UserVolume, UserBucket, UserToken } from '../../services/userApi';

const UserDashboardDebug: React.FC = () => {
  const userId = userApi.getCurrentUserId();

  // Test all user endpoints
  const { data: dashboardData, isLoading: dashboardLoading, error: dashboardError } = useQuery({
    queryKey: ['user-dashboard-debug', userId],
    queryFn: () => userApi.getDashboard(userId),
    enabled: true,
  });

  const { data: dropletsData, isLoading: dropletsLoading, error: dropletsError } = useQuery({
    queryKey: ['user-droplets-debug', userId],
    queryFn: () => userApi.getDroplets(userId),
    enabled: true,
  });

  const { data: volumesData, isLoading: volumesLoading, error: volumesError } = useQuery({
    queryKey: ['user-volumes-debug', userId],
    queryFn: () => userApi.getVolumes(userId),
    enabled: true,
  });

  const { data: bucketsData, isLoading: bucketsLoading, error: bucketsError } = useQuery({
    queryKey: ['user-buckets-debug', userId],
    queryFn: () => userApi.getBuckets(userId),
    enabled: true,
  });

  const { data: tokensData, isLoading: tokensLoading, error: tokensError } = useQuery({
    queryKey: ['user-tokens-debug', userId],
    queryFn: () => userApi.getTokens(userId),
    enabled: true,
  });

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <div className="bg-white shadow-lg rounded-lg p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">
          🔍 User API Debug Dashboard
        </h1>
        <p className="text-gray-600 mb-4">
          Testing user-specific endpoints for User ID: <code className="bg-gray-100 px-2 py-1 rounded">{userId}</code>
        </p>
      </div>

      {/* Dashboard Data */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">📊 Dashboard Data</h2>
        {dashboardLoading && <div className="text-blue-600">Loading dashboard...</div>}
        {dashboardError && (
          <div className="text-red-600">
            Error: {dashboardError instanceof Error ? dashboardError.message : 'Unknown error'}
          </div>
        )}
        {dashboardData && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{dashboardData.summary?.total_droplets || 0}</div>
                <div className="text-sm text-blue-800">Droplets</div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{dashboardData.summary?.total_volumes || 0}</div>
                <div className="text-sm text-purple-800">Volumes</div>
              </div>
              <div className="bg-indigo-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-indigo-600">{dashboardData.summary?.total_buckets || 0}</div>
                <div className="text-sm text-indigo-800">Buckets</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{dashboardData.summary?.active_tokens || 0}</div>
                <div className="text-sm text-green-800">Tokens</div>
              </div>
            </div>
            <details className="mt-4">
              <summary className="cursor-pointer text-gray-700 font-medium">View Raw Dashboard Data</summary>
              <pre className="mt-2 p-4 bg-gray-100 rounded text-xs overflow-auto">
                {JSON.stringify(dashboardData, null, 2)}
              </pre>
            </details>
          </div>
        )}
      </div>

      {/* Droplets Data */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">🖥️ Droplets Data</h2>
        {dropletsLoading && <div className="text-blue-600">Loading droplets...</div>}
        {dropletsError && (
          <div className="text-red-600">
            Error: {dropletsError instanceof Error ? dropletsError.message : 'Unknown error'}
          </div>
        )}
        {dropletsData && (
          <div className="space-y-2">
            <div className="text-sm text-gray-600">Found {dropletsData.length} droplets</div>
            {dropletsData.map((droplet: any, index: number) => (
              <div key={droplet.id || index} className="border border-gray-200 rounded p-3">
                <div className="font-medium">{droplet.name}</div>
                <div className="text-sm text-gray-600">
                  ID: {droplet.id} | Status: {droplet.status} | Region: {droplet.region?.name || droplet.region?.slug}
                </div>
              </div>
            ))}
            <details className="mt-4">
              <summary className="cursor-pointer text-gray-700 font-medium">View Raw Droplets Data</summary>
              <pre className="mt-2 p-4 bg-gray-100 rounded text-xs overflow-auto">
                {JSON.stringify(dropletsData, null, 2)}
              </pre>
            </details>
          </div>
        )}
      </div>

      {/* Volumes Data */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">💾 Volumes Data</h2>
        {volumesLoading && <div className="text-blue-600">Loading volumes...</div>}
        {volumesError && (
          <div className="text-red-600">
            Error: {volumesError instanceof Error ? volumesError.message : 'Unknown error'}
          </div>
        )}
        {volumesData && (
          <div className="space-y-2">
            <div className="text-sm text-gray-600">Found {volumesData.length} volumes</div>
            {volumesData.map((volume: any, index: number) => (
              <div key={volume.id || index} className="border border-gray-200 rounded p-3">
                <div className="font-medium">{volume.name}</div>
                <div className="text-sm text-gray-600">
                  ID: {volume.id} | Size: {volume.size_gigabytes}GB | Status: {volume.status}
                </div>
              </div>
            ))}
            <details className="mt-4">
              <summary className="cursor-pointer text-gray-700 font-medium">View Raw Volumes Data</summary>
              <pre className="mt-2 p-4 bg-gray-100 rounded text-xs overflow-auto">
                {JSON.stringify(volumesData, null, 2)}
              </pre>
            </details>
          </div>
        )}
      </div>

      {/* Buckets Data */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">☁️ Buckets Data</h2>
        {bucketsLoading && <div className="text-blue-600">Loading buckets...</div>}
        {bucketsError && (
          <div className="text-red-600">
            Error: {bucketsError instanceof Error ? bucketsError.message : 'Unknown error'}
          </div>
        )}
        {bucketsData && (
          <div className="space-y-2">
            <div className="text-sm text-gray-600">Found {bucketsData.length} buckets</div>
            {bucketsData.map((bucket: any, index: number) => (
              <div key={`${bucket.name}-${index}`} className="border border-gray-200 rounded p-3">
                <div className="font-medium">{bucket.name}</div>
                <div className="text-sm text-gray-600">
                  Region: {bucket.region} | Created: {bucket.creation_date || 'N/A'}
                </div>
              </div>
            ))}
            <details className="mt-4">
              <summary className="cursor-pointer text-gray-700 font-medium">View Raw Buckets Data</summary>
              <pre className="mt-2 p-4 bg-gray-100 rounded text-xs overflow-auto">
                {JSON.stringify(bucketsData, null, 2)}
              </pre>
            </details>
          </div>
        )}
      </div>

      {/* Tokens Data */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">🔑 Tokens Data</h2>
        {tokensLoading && <div className="text-blue-600">Loading tokens...</div>}
        {tokensError && (
          <div className="text-red-600">
            Error: {tokensError instanceof Error ? tokensError.message : 'Unknown error'}
          </div>
        )}
        {tokensData && (
          <div className="space-y-2">
            <div className="text-sm text-gray-600">Found {tokensData.length} tokens</div>
            {tokensData.map((token: any, index: number) => (
              <div key={token.index || index} className="border border-gray-200 rounded p-3">
                <div className="font-medium">{token.account_name}</div>
                <div className="text-sm text-gray-600">
                  Token: {token.masked_token} | Status: {token.status}
                </div>
              </div>
            ))}
            <details className="mt-4">
              <summary className="cursor-pointer text-gray-700 font-medium">View Raw Tokens Data</summary>
              <pre className="mt-2 p-4 bg-gray-100 rounded text-xs overflow-auto">
                {JSON.stringify(tokensData, null, 2)}
              </pre>
            </details>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserDashboardDebug;
