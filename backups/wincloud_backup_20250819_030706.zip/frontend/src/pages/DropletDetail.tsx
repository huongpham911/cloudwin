import React from 'react'
import DropletManagement from '../components/droplets/DropletManagement'

const DropletDetail: React.FC = () => {
  return <DropletManagement />
}

export default DropletDetail
