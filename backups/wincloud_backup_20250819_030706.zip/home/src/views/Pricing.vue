<template>
  <div class="pricing-page">
    <div class="hero-section">
      <div class="container">
        <h1 class="hero-title">Bảng giá WinCloud</h1>
        <p class="hero-subtitle">
          Chọn gói phù hợp với nhu cầu của bạn. Minh bạch, không phí ẩn
        </p>
      </div>
    </div>

    <div class="pricing-section">
      <div class="container">
        <div class="pricing-grid">
          <div class="pricing-card">
            <div class="card-header">
              <h3 class="plan-name">Starter</h3>
              <div class="price">
                <span class="price-amount">$15</span>
                <span class="price-period">/tháng</span>
              </div>
              <p class="plan-description">Phù hợp cho cá nhân và startup</p>
            </div>

            <div class="card-body">
              <ul class="feature-list">
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  2 CPU Cores
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  4GB RAM
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  50GB SSD Storage
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  2TB Bandwidth
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  Windows Server 2022
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  RDP Access
                </li>
              </ul>
            </div>

            <div class="card-footer">
              <button class="btn-plan btn-secondary">Chọn gói này</button>
            </div>
          </div>

          <div class="pricing-card popular">
            <div class="popular-badge">Phổ biến nhất</div>
            <div class="card-header">
              <h3 class="plan-name">Professional</h3>
              <div class="price">
                <span class="price-amount">$35</span>
                <span class="price-period">/tháng</span>
              </div>
              <p class="plan-description">Tối ưu cho doanh nghiệp vừa</p>
            </div>

            <div class="card-body">
              <ul class="feature-list">
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  4 CPU Cores
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  8GB RAM
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  100GB SSD Storage
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  4TB Bandwidth
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  Windows Server 2022
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  RDP Access
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  Auto Backup
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  24/7 Support
                </li>
              </ul>
            </div>

            <div class="card-footer">
              <button class="btn-plan btn-primary">Chọn gói này</button>
            </div>
          </div>

          <div class="pricing-card">
            <div class="card-header">
              <h3 class="plan-name">Enterprise</h3>
              <div class="price">
                <span class="price-amount">$75</span>
                <span class="price-period">/tháng</span>
              </div>
              <p class="plan-description">Cho doanh nghiệp lớn</p>
            </div>

            <div class="card-body">
              <ul class="feature-list">
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  8 CPU Cores
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  16GB RAM
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  200GB SSD Storage
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  8TB Bandwidth
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  Windows Server 2022
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  RDP Access
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  Auto Backup
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  24/7 Priority Support
                </li>
                <li class="feature-item">
                  <span class="feature-icon">✓</span>
                  Custom Configuration
                </li>
              </ul>
            </div>

            <div class="card-footer">
              <button class="btn-plan btn-secondary">Chọn gói này</button>
            </div>
          </div>
        </div>

        <div class="faq-section">
          <h2 class="section-title">Câu hỏi thường gặp</h2>
          <div class="faq-grid">
            <div class="faq-item">
              <h4>Tôi có thể thay đổi gói bất cứ lúc nào?</h4>
              <p>
                Có, bạn có thể nâng cấp hoặc hạ cấp gói bất cứ lúc nào. Phí sẽ
                được tính theo tỷ lệ.
              </p>
            </div>
            <div class="faq-item">
              <h4>Có được hoàn tiền không?</h4>
              <p>
                Chúng tôi cung cấp chính sách hoàn tiền 30 ngày cho khách hàng
                mới.
              </p>
            </div>
            <div class="faq-item">
              <h4>Thời gian thiết lập server là bao lâu?</h4>
              <p>
                Server của bạn sẽ sẵn sàng trong vòng 5-10 phút sau khi thanh
                toán thành công.
              </p>
            </div>
            <div class="faq-item">
              <h4>Có hỗ trợ kỹ thuật không?</h4>
              <p>
                Có, chúng tôi cung cấp hỗ trợ 24/7 qua chat, email và điện
                thoại.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
// Component logic here
</script>

<style scoped>
.pricing-page {
  min-height: calc(100vh - 70px);
}

.hero-section {
  background: linear-gradient(135deg, #10b981, #059669);
  color: white;
  padding: 4rem 0;
  text-align: center;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 2rem;
}

.hero-title {
  font-size: 3rem;
  font-weight: 700;
  margin-bottom: 1rem;
}

.hero-subtitle {
  font-size: 1.25rem;
  opacity: 0.9;
  max-width: 600px;
  margin: 0 auto;
}

.pricing-section {
  padding: 4rem 0;
  background: #f9fafb;
}

.pricing-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
  margin-bottom: 4rem;
}

.pricing-card {
  background: white;
  border-radius: 1rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);
  overflow: hidden;
  position: relative;
  transition: transform 0.3s ease;
}

.pricing-card:hover {
  transform: translateY(-5px);
}

.pricing-card.popular {
  border: 2px solid #3b82f6;
  transform: scale(1.05);
}

.popular-badge {
  background: #3b82f6;
  color: white;
  text-align: center;
  padding: 0.5rem;
  font-weight: 600;
  font-size: 0.875rem;
}

.card-header {
  padding: 2rem 2rem 1rem;
  text-align: center;
}

.plan-name {
  font-size: 1.5rem;
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 1rem;
}

.price {
  margin-bottom: 1rem;
}

.price-amount {
  font-size: 3rem;
  font-weight: 700;
  color: #3b82f6;
}

.price-period {
  color: #6b7280;
  font-size: 1rem;
}

.plan-description {
  color: #6b7280;
  font-size: 0.875rem;
}

.card-body {
  padding: 0 2rem;
}

.feature-list {
  list-style: none;
  padding: 0;
}

.feature-item {
  display: flex;
  align-items: center;
  padding: 0.75rem 0;
  border-bottom: 1px solid #f3f4f6;
}

.feature-item:last-child {
  border-bottom: none;
}

.feature-icon {
  color: #10b981;
  font-weight: 700;
  margin-right: 0.75rem;
  font-size: 1.125rem;
}

.card-footer {
  padding: 2rem;
}

.btn-plan {
  width: 100%;
  padding: 0.875rem;
  border: none;
  border-radius: 0.5rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 1rem;
}

.btn-primary {
  background: linear-gradient(135deg, #3b82f6, #1d4ed8);
  color: white;
}

.btn-primary:hover {
  background: linear-gradient(135deg, #2563eb, #1e40af);
  transform: translateY(-1px);
}

.btn-secondary {
  background: #f9fafb;
  color: #374151;
  border: 2px solid #e5e7eb;
}

.btn-secondary:hover {
  background: #f3f4f6;
  border-color: #3b82f6;
  color: #3b82f6;
}

.faq-section {
  text-align: center;
}

.section-title {
  font-size: 2.5rem;
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 3rem;
}

.faq-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  text-align: left;
}

.faq-item {
  background: white;
  padding: 2rem;
  border-radius: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.faq-item h4 {
  color: #1f2937;
  font-weight: 600;
  margin-bottom: 1rem;
  font-size: 1.125rem;
}

.faq-item p {
  color: #6b7280;
  line-height: 1.6;
}

@media (max-width: 768px) {
  .hero-title {
    font-size: 2rem;
  }

  .pricing-card.popular {
    transform: none;
  }

  .pricing-grid {
    grid-template-columns: 1fr;
  }
}
</style>
