<template>
  <div class="home">
    <!-- Hero Section -->
    <section class="hero">
      <div class="hero-container">
        <div class="hero-content">
          <h1 class="hero-title">
            Windows RDP
            <span class="hero-highlight">trên Cloud</span>
          </h1>
          <p class="hero-subtitle">
            Tạo và quản lý Windows Server trên DigitalOcean một cách dễ dàng,
            nhanh chóng và tiết kiệm chi phí
          </p>
          <div class="hero-buttons">
            <a
              href="http://localhost:5173/register"
              class="btn btn-primary"
              target="_blank"
            >
              🚀 Bắt đầu ngay
            </a>
            <a
              href="http://localhost:5173/login"
              class="btn btn-secondary"
              target="_blank"
            >
              👤 Đăng nhập
            </a>
          </div>
        </div>
        <div class="hero-stats">
          <div class="stat-item">
            <span class="stat-number">1000+</span>
            <span class="stat-label">Servers đã tạo</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">99.9%</span>
            <span class="stat-label">Uptime</span>
          </div>
          <div class="stat-item">
            <span class="stat-number">24/7</span>
            <span class="stat-label">Hỗ trợ</span>
          </div>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="features">
      <div class="container">
        <h2 class="section-title">Tại sao chọn WinCloud?</h2>
        <div class="features-grid">
          <div class="feature-card">
            <div class="feature-icon">⚡</div>
            <h3 class="feature-title">Triển khai tức thì</h3>
            <p class="feature-description">
              Tạo Windows Server trong vài phút với giao diện đơn giản
            </p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🚀</div>
            <h3 class="feature-title">Hiệu suất cao</h3>
            <p class="feature-description">
              SSD NVMe, RAM DDR4 và CPU Intel mới nhất
            </p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🛡️</div>
            <h3 class="feature-title">Bảo mật tối đa</h3>
            <p class="feature-description">
              Firewall tự động, SSL và backup định kỳ
            </p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">💬</div>
            <h3 class="feature-title">Hỗ trợ 24/7</h3>
            <p class="feature-description">
              Đội ngũ kỹ thuật sẵn sàng hỗ trợ mọi lúc
            </p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">💰</div>
            <h3 class="feature-title">Giá cả cạnh tranh</h3>
            <p class="feature-description">
              Chỉ trả tiền cho những gì bạn sử dụng
            </p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">📊</div>
            <h3 class="feature-title">Quản lý dễ dàng</h3>
            <p class="feature-description">
              Dashboard trực quan, thao tác đơn giản
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- Pricing Section -->
    <section class="pricing">
      <div class="container">
        <h2 class="section-title">Bảng giá đơn giản, minh bạch</h2>
        <p class="section-subtitle">Chọn gói phù hợp với nhu cầu của bạn</p>
        <div class="pricing-grid">
          <div class="pricing-card">
            <div class="pricing-header">
              <h3 class="pricing-name">Basic</h3>
              <div class="pricing-price">
                <span class="price-amount">$15</span>
                <span class="price-period">/tháng</span>
              </div>
            </div>
            <ul class="pricing-features">
              <li>✓ 2 CPU Cores</li>
              <li>✓ 4GB RAM</li>
              <li>✓ 50GB SSD</li>
              <li>✓ 2TB Bandwidth</li>
              <li>✓ Windows Server 2022</li>
              <li>✓ RDP Access</li>
            </ul>
            <a
              href="http://localhost:5173/register"
              class="btn btn-secondary"
              target="_blank"
            >
              Chọn gói này
            </a>
          </div>

          <div class="pricing-card featured">
            <div class="popular-badge">Phổ biến nhất</div>
            <div class="pricing-header">
              <h3 class="pricing-name">Pro</h3>
              <div class="pricing-price">
                <span class="price-amount">$35</span>
                <span class="price-period">/tháng</span>
              </div>
            </div>
            <ul class="pricing-features">
              <li>✓ 4 CPU Cores</li>
              <li>✓ 8GB RAM</li>
              <li>✓ 100GB SSD</li>
              <li>✓ 4TB Bandwidth</li>
              <li>✓ Windows Server 2022</li>
              <li>✓ RDP Access</li>
              <li>✓ Auto Backup</li>
              <li>✓ 24/7 Support</li>
            </ul>
            <a
              href="http://localhost:5173/register"
              class="btn btn-primary"
              target="_blank"
            >
              Chọn gói này
            </a>
          </div>

          <div class="pricing-card">
            <div class="pricing-header">
              <h3 class="pricing-name">Enterprise</h3>
              <div class="pricing-price">
                <span class="price-amount">$75</span>
                <span class="price-period">/tháng</span>
              </div>
            </div>
            <ul class="pricing-features">
              <li>✓ 8 CPU Cores</li>
              <li>✓ 16GB RAM</li>
              <li>✓ 200GB SSD</li>
              <li>✓ 8TB Bandwidth</li>
              <li>✓ Windows Server 2022</li>
              <li>✓ RDP Access</li>
              <li>✓ Auto Backup</li>
              <li>✓ 24/7 Support</li>
              <li>✓ Custom Setup</li>
            </ul>
            <a
              href="http://localhost:5173/register"
              class="btn btn-secondary"
              target="_blank"
            >
              Chọn gói này
            </a>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
      <div class="container">
        <div class="cta-content">
          <h2 class="cta-title">Sẵn sàng bắt đầu?</h2>
          <p class="cta-subtitle">
            Tham gia cùng hàng nghìn khách hàng đã tin tưởng WinCloud
          </p>
          <a
            href="http://localhost:5173/register"
            class="btn btn-primary cta-button"
            target="_blank"
          >
            Tạo tài khoản miễn phí
          </a>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
// No additional logic needed for this static page
</script>

<style scoped>
.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
}

/* Hero Section */
.hero {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 4rem 0;
  color: white;
  position: relative;
  overflow: hidden;
}

.hero::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.1);
}

.hero-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
  position: relative;
  z-index: 1;
}

.hero-content {
  text-align: center;
  margin-bottom: 3rem;
}

.hero-title {
  font-size: 3.5rem;
  font-weight: 800;
  margin-bottom: 1.5rem;
  line-height: 1.2;
}

.hero-highlight {
  background: linear-gradient(45deg, #ffd700, #ffed4a);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.hero-subtitle {
  font-size: 1.25rem;
  margin-bottom: 2rem;
  opacity: 0.9;
  max-width: 600px;
  margin-left: auto;
  margin-right: auto;
}

.hero-buttons {
  display: flex;
  gap: 1rem;
  justify-content: center;
  flex-wrap: wrap;
}

.hero-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  margin-top: 3rem;
}

.stat-item {
  text-align: center;
  padding: 1.5rem;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 1rem;
  backdrop-filter: blur(10px);
}

.stat-number {
  display: block;
  font-size: 2.5rem;
  font-weight: 800;
  color: #ffd700;
  margin-bottom: 0.5rem;
}

.stat-label {
  font-size: 1rem;
  opacity: 0.8;
}

/* Features Section */
.features {
  padding: 5rem 0;
  background: white;
}

.section-title {
  text-align: center;
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 3rem;
  color: #1f2937;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
}

.feature-card {
  padding: 2rem;
  background: #f8fafc;
  border-radius: 1rem;
  text-align: center;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  border: 1px solid #e2e8f0;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.feature-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
}

.feature-title {
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: #1f2937;
}

.feature-description {
  color: #6b7280;
  line-height: 1.6;
}

/* Pricing Section */
.pricing {
  padding: 5rem 0;
  background: #f8fafc;
}

.section-subtitle {
  text-align: center;
  font-size: 1.125rem;
  color: #6b7280;
  margin-bottom: 3rem;
}

.pricing-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  max-width: 1000px;
  margin: 0 auto;
}

.pricing-card {
  background: white;
  border-radius: 1rem;
  padding: 2rem;
  position: relative;
  border: 2px solid #e5e7eb;
  transition: all 0.3s ease;
}

.pricing-card:hover {
  border-color: #3b82f6;
  transform: translateY(-5px);
  box-shadow: 0 10px 25px rgba(59, 130, 246, 0.15);
}

.pricing-card.featured {
  border-color: #3b82f6;
  transform: scale(1.05);
}

.popular-badge {
  position: absolute;
  top: -10px;
  left: 50%;
  transform: translateX(-50%);
  background: linear-gradient(135deg, #ffd700, #ffed4a);
  color: #1f2937;
  padding: 0.5rem 1rem;
  border-radius: 1rem;
  font-size: 0.875rem;
  font-weight: 600;
}

.pricing-header {
  text-align: center;
  margin-bottom: 2rem;
}

.pricing-name {
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
  color: #1f2937;
}

.pricing-price {
  display: flex;
  align-items: baseline;
  justify-content: center;
  gap: 0.25rem;
}

.price-amount {
  font-size: 3rem;
  font-weight: 800;
  color: #3b82f6;
}

.price-period {
  font-size: 1rem;
  color: #6b7280;
}

.pricing-features {
  list-style: none;
  margin-bottom: 2rem;
}

.pricing-features li {
  padding: 0.5rem 0;
  color: #374151;
}

/* CTA Section */
.cta {
  padding: 5rem 0;
  background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
  color: white;
}

.cta-content {
  text-align: center;
  max-width: 600px;
  margin: 0 auto;
}

.cta-title {
  font-size: 2.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
}

.cta-subtitle {
  font-size: 1.125rem;
  margin-bottom: 2rem;
  opacity: 0.9;
}

.cta-button {
  font-size: 1.125rem;
  padding: 1rem 2rem;
}

/* Responsive Design */
@media (max-width: 768px) {
  .hero-title {
    font-size: 2.5rem;
  }

  .hero-buttons {
    flex-direction: column;
    align-items: center;
  }

  .hero-stats {
    grid-template-columns: 1fr;
  }

  .features-grid,
  .pricing-grid {
    grid-template-columns: 1fr;
  }

  .pricing-card.featured {
    transform: none;
  }

  .section-title {
    font-size: 2rem;
  }

  .cta-title {
    font-size: 2rem;
  }
}

@media (max-width: 480px) {
  .hero-title {
    font-size: 2rem;
  }

  .stat-number {
    font-size: 2rem;
  }

  .price-amount {
    font-size: 2.5rem;
  }
}
</style>
