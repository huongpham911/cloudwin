# Main app package initialization
